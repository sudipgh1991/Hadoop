package MapRed2Assignment4;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class Task1Partioner extends Partitioner<Text, Text> {

	@Override
	public int getPartition(Text key, Text value, int numPartitions) {			
		
		
		String compName=key.toString();
		if(compName.toLowerCase().charAt(0)>='a'&& compName.toLowerCase().charAt(0)<='f')
			return 0;
		else if(compName.toLowerCase().charAt(0)>='g'&& compName.toLowerCase().charAt(0)<='l')
			return 1;
		else if(compName.toLowerCase().charAt(0)>='m'&& compName.toLowerCase().charAt(0)<='r')
			return 2;
		else
			return 3;
		
	}
}