package MapRed2Assignment8;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Task1Reducer extends Reducer<Text, Text, Text, Text>
{	
	public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException
	{
		
		int countDiffComp=1;
		ArrayList<String>list=new ArrayList<String>();
		ArrayList<String>listunique=new ArrayList<String>();
		String comp="";String output="";
		for(Text value : values)
		{
			list.add(value.toString());
				
			
	
		}
		Set<String> unique=new HashSet<String>(list);
		String [] wordCount=new String[unique.size()];
		int pos=0;
		for(int i=0;i<unique.size();i++)
		{
			
			
			countDiffComp=Collections.frequency(list, unique.iterator().next());
			wordCount[pos]=countDiffComp+"";
			pos++;
					
		}
		
		
		
		
		for(int i=0;i<unique.size();i++)
		{
			output+=unique.iterator().next()+"->"+wordCount[i]+",";
		}
		
		
		context.write(key, new Text(output+""));
	}
}
