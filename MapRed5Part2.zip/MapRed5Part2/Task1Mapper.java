package MapRed2Assignment8;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.*; 

public class Task1Mapper extends Mapper<LongWritable, Text, Text, Text> {
	@Override
		public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException {
		String[] lineArray = value.toString().split("\\|");
		String qtySold="";
//		
		qtySold=lineArray[0];
		Text txtValue=new Text(qtySold);
		
		String companyName=lineArray[1]+lineArray[2];
		Text txtKey=new Text(companyName);
		
		
		context.write(txtKey, txtValue);
//		
		
	}
}
